/*
 * Copyright 2006 Sun Microsystems, Inc.  All rights reserved.
 * You may not modify, use, reproduce, or distribute this
 * software except in compliance with the terms of the License at:
 *
 *   http://developer.sun.com/berkeley_license.html
 *
 * $Id: Pauser.java,v 1.1 2006/04/27 02:16:39 mattbohm Exp $
 */

package com.sun.j2ee.blueprints.ui.progressbar;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

/**
 * Interface implemented by classes which can pause a long-running task.
 *
 * @author Matthew Bohm
 */
public interface Pauser {
    /** This method is called asynchronously from client scripting.
     * It pauses a long-running task.
     *
     */
    public void pauseTask(FacesContext context);

}
