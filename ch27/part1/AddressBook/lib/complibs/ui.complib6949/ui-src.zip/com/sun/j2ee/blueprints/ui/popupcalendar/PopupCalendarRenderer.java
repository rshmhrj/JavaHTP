/*
 * Copyright 2006 Sun Microsystems, Inc.  All rights reserved.
 * You may not modify, use, reproduce, or distribute this
 * software except in compliance with the terms of the License at:
 *
 *   http://developer.sun.com/berkeley_license.html
 *
 * $Id: PopupCalendarRenderer.java,v 1.2 2006/04/26 04:03:02 craig_mcc Exp $
 */

package com.sun.j2ee.blueprints.ui.popupcalendar;

import java.beans.Beans;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.faces.component.UIComponent;
import javax.faces.component.html.HtmlCommandButton;
import javax.faces.component.html.HtmlPanelGrid;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import javax.faces.render.Renderer;

import org.apache.shale.remoting.Mechanism;
import org.apache.shale.remoting.XhtmlHelper;

import com.sun.j2ee.blueprints.ui.util.Util;

/**
 * <p>
 * This renderer generates HTML (including JavaScript) for
 * PopupCalendarComponent.
 * </p>
 * 
 * @author Edwin Goei
 */
public class PopupCalendarRenderer extends Renderer {

    // ------------------------------------------------------ Manifest Constants

    /** CSS for top level text field and icon */
    private static final String POP_CAL_CSS = "/META-INF/popupcalendar/PopupCalendar.css";

    /** CSS for subcomponent calendar showing a single month */
    private static final String CALENDAR_CSS = "/META-INF/popupcalendar/Calendar.css";

    /** Dojo package file for "dojo.widget.*" */
    private static final String DOJO_WIDGET_PACKAGE = "/META-INF/dojo/src/widget/__package__.js";

    /** Dojo package file for "popupcalendar.*" */
    private static final String POP_CAL_PACKAGE = "/META-INF/popupcalendar/__package__.js";

    /** Calendar icon */
    private static final String CALENDAR_ICON = "/META-INF/popupcalendar/PopupCalendar.png";

    /** CSS class for popup button */
    private static final String POP_CAL_BUTTON_CLASS = "PopCalButton";

    private static final String POP_CAL_MODULE_NAME = "popupcalendar";

    /** Suffix for element in markup where the calendar subcomponent will appear */
    private static final String POP_CAL_CALENDAR_SUFFIX = "_calendar";

    /** CSS class for location of subcomponent calendar showing a single month */
    private static final Object POP_CAL_CALENDAR_CLASS = "PopCalPopup";

    // -------------------------------------------------------- Static Variables

    /**
     * <p>
     * HTML attributes with boolean values that are passed through to the
     * rendered output.
     * </p>
     */
    private static String booleanPassthruAttributes[] = { "disabled",
            "readonly", "ismap" };

    /**
     * <p>
     * HTML attributes with integer values that are passed through to the
     * rendered output.
     * </p>
     */
    private static String integerPassthruAttributes[] = { "maxlength", "size" };

    /**
     * <p>
     * HTML attributes with String values that are passed through to the
     * rendered output.
     * </p>
     */
    private static String passthruAttributes[] = { "accept", "accesskey",
            "alt", "bgcolor", "border", "cellpadding", "cellspacing",
            "charset", "cols", "coords", "dir", "enctype", "frame", "height",
            "hreflang", "lang", "longdesc", "onblur", "onchange", "onclick",
            "ondblclick", "onfocus", "onkeydown", "onkeypress", "onkeyup",
            "onload", "onmousedown", "onmousemove", "onmouseout",
            "onmouseover", "onmouseup", "onreset", "onselect", "onsubmit",
            "onunload", "rel", "rev", "rows", "rules", "shape", "style",
            "summary", "tabindex", "target", "title", "usemap", "width" };

    /**
     * <p>
     * Stateless helper bean to manufacture resource linkages.
     * </p>
     */
    private static XhtmlHelper helper = new XhtmlHelper();

    // -------------------------------------------------------- Renderer Methods

    /**
     * <p>
     * Decode the submitted value for this component.
     * </p>
     * 
     * @param context
     *            <code>FacesContext</code> for the current request
     * @param component
     *            <code>UIComponent</code> being decoded
     */
    public void decode(FacesContext context, UIComponent component) {

        if ((context == null) || (component == null)) {
            throw new NullPointerException();
        }

        PopupCalendarComponent popCal = (PopupCalendarComponent) component;
        if (popCal.isDisabled() || popCal.isReadonly()) {
            return;
        }

        String clientId = popCal.getInputTextClientId(context);
        String submittedValue = (String) context.getExternalContext()
                .getRequestParameterMap().get(clientId);
        popCal.setSubmittedValue(submittedValue);
    }

    /**
     * <p>
     * Render the HTML for this component.
     * </p>
     * 
     * @param context
     *            <code>FacesContext</code> for the current request
     * @param component
     *            <code>UIComponent</code> being rendered
     * 
     * @exception IOException
     *                if an input/output error occurs
     */
    public void encodeEnd(FacesContext context, UIComponent component)
            throws IOException {

        // Prepare the local variables we will need
        PopupCalendarComponent popCal = (PopupCalendarComponent) component;
        String clientId = popCal.getClientId(context);
        ResponseWriter writer = context.getResponseWriter();
        writer.startElement("div", popCal);
        writer.writeAttribute("id", clientId, "id");

        // Renders @style in particular
        renderStringPassThruAttributes(writer, component);

        // Render the CSS style class(es) (if any)
        String styleClass = popCal.getStyleClass();
        if (styleClass != null) {
            writer.writeAttribute("class", styleClass, "styleClass");
        }
        // TODO what about other attributes?

        // Render the required resource links once per page (runtime only)
        if (!Beans.isDesignTime()) {
            helper.linkStylesheet(context, component, writer,
                    Mechanism.CLASS_RESOURCE, CALENDAR_CSS);
            helper.linkStylesheet(context, component, writer,
                    Mechanism.CLASS_RESOURCE, POP_CAL_CSS);

            helper.linkJavascript(context, component, writer,
                    Mechanism.CLASS_RESOURCE, Util.UI_COMMON_SCRIPT_RESOURCE);
            Util.renderDojoLoading(context, component, writer);

            writer.startElement("script", component);
            writer.writeAttribute("type", "text/javascript", null);
            writer.write("\n");
            writer.write("dojo.setModulePrefix('" + POP_CAL_MODULE_NAME
                    + "', '../" + POP_CAL_MODULE_NAME + "');");
            writer.write("\n");
            writer.endElement("script");
            writer.write("\n");

            helper.linkJavascript(context, component, writer,
                    Mechanism.CLASS_RESOURCE, DOJO_WIDGET_PACKAGE);
            helper.linkJavascript(context, component, writer,
                    Mechanism.CLASS_RESOURCE, POP_CAL_PACKAGE);
        }

        // Wrap components in a panel for spacing
        HtmlPanelGrid mainPanel = new HtmlPanelGrid();
        mainPanel.setColumns(2);
        List panelChildren = mainPanel.getChildren();
        panelChildren.add(popCal.getInputText(context));

        HtmlCommandButton button = new HtmlCommandButton();
        button.setStyleClass(POP_CAL_BUTTON_CLASS);
        button.setImage(getImageUrl(context, component, CALENDAR_ICON));
        button.setAlt(Util.getMessage("popupcalendar.buttonAlt"));
        String script = popCal.getJavaScriptObjectName(context)
                + ".toggle();return false;";
        button.setOnclick(script);
        panelChildren.add(button);

        renderComponent(context, mainPanel);

        // Render a div to use as a target location for the popup
        writer.startElement("div", popCal);
        writer.writeAttribute("id", popCal.getJavaScriptObjectName(context)
                + POP_CAL_CALENDAR_SUFFIX, null);
        writer.writeAttribute("class", POP_CAL_CALENDAR_CLASS, null);
        writer.endElement("div");
        writer.write("\n");

        renderScript(writer, component, popCal
                .getJavaScriptForNewInstance(context));

        // Render the end of top level div
        writer.endElement("div");
        writer.write("\n");
    }

    // ------------------------------------------------------==- Private Methods

    /**
     * <p>
     * Render pass-through HTML attributes with boolean values.
     * </p>
     * 
     * @param writer
     *            <code>ResponseWriter</code> to render with
     * @param component
     *            <code>UIComponent</code> being rendered
     */
    private void renderBooleanPassThruAttributes(ResponseWriter writer,
            UIComponent component) throws IOException {

        boolean result = false;
        Object value;
        for (int i = 0; i < booleanPassthruAttributes.length; i++) {
            value = component.getAttributes().get(booleanPassthruAttributes[i]);
            if (value != null) {
                if (value instanceof Boolean) {
                    result = ((Boolean) value).booleanValue();
                } else if (value instanceof String) {
                    result = (new Boolean((String) value)).booleanValue();
                }
                if (result) {
                    writer.writeAttribute(booleanPassthruAttributes[i],
                            booleanPassthruAttributes[i],
                            booleanPassthruAttributes[i]);
                }
            }
        }

    }

    /**
     * <p>
     * Render pass-through HTML attributes with integer values.
     * </p>
     * 
     * @param writer
     *            <code>ResponseWriter</code> to render with
     * @param component
     *            <code>UIComponent</code> being rendered
     */
    private void renderIntegerPassThruAttributes(ResponseWriter writer,
            UIComponent component) throws IOException {

        Object value;
        for (int i = 0; i < integerPassthruAttributes.length; i++) {
            value = component.getAttributes().get(integerPassthruAttributes[i]);
            if ((value != null) && (value instanceof Integer)) {
                int intValue = ((Integer) value).intValue();
                if (intValue != Integer.MIN_VALUE) {
                    writer.writeAttribute(integerPassthruAttributes[i], value
                            .toString(), integerPassthruAttributes[i]);
                }
            }
        }

    }

    /**
     * <p>
     * Render pass-through HTML attributes with String values.
     * </p>
     * 
     * @param writer
     *            <code>ResponseWriter</code> to render with
     * @param component
     *            <code>UIComponent</code> being rendered
     */
    private void renderStringPassThruAttributes(ResponseWriter writer,
            UIComponent component) throws IOException {

        Object value;
        for (int i = 0; i < passthruAttributes.length; i++) {
            value = component.getAttributes().get(passthruAttributes[i]);
            if (value != null) {
                if (!(value instanceof String)) {
                    value = value.toString();
                }
                writer.writeAttribute(passthruAttributes[i], (String) value,
                        passthruAttributes[i]);
            }
        }

    }

    private void renderComponent(FacesContext context, UIComponent component)
            throws IOException {
        if (!component.isRendered()) {
            return;
        }

        component.encodeBegin(context);
        if (component.getRendersChildren()) {
            component.encodeChildren(context);
        } else {
            Iterator kids = component.getChildren().iterator();
            while (kids.hasNext()) {
                UIComponent kid = (UIComponent) kids.next();
                renderComponent(context, kid);
            }
        }
        component.encodeEnd(context);
    }

    private void renderScript(ResponseWriter writer, UIComponent component,
            String script) throws IOException {
        writer.startElement("script", component);
        writer.writeAttribute("type", "text/javascript", null);
        writer.write("\n");
        writer.write(script);
        writer.endElement("script");
        writer.write("\n");
    }

    private String getImageUrl(FacesContext context, UIComponent component,
            String resourcePath) {
        if (Beans.isDesignTime()) {
            return component.getClass().getResource(resourcePath).toString();
        } else {
            return helper.mapResourceId(context, Mechanism.CLASS_RESOURCE,
                    resourcePath);
        }
    }
}
