/*
 * Copyright 2006 Sun Microsystems, Inc.  All rights reserved.
 * You may not modify, use, reproduce, or distribute this
 * software except in compliance with the terms of the License at:
 *
 *   http://developer.sun.com/berkeley_license.html
 *
 * $Id: PopupCalendarComponent.java,v 1.3 2006/04/20 07:09:43 edwingo Exp $
 */

package com.sun.j2ee.blueprints.ui.popupcalendar;

import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.application.FacesMessage;
import javax.faces.component.NamingContainer;
import javax.faces.component.html.HtmlInputText;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.el.ValueBinding;

import com.sun.j2ee.blueprints.ui.util.Util;

/**
 * Date picker with a JavaScript popup calendar
 * 
 * @author Edwin Goei
 */
public class PopupCalendarComponent extends HtmlInputText {
    private static final String FIELD_SUFFIX = "_field";

    /** ISO 8601 date format pattern */
    private static final String ISO_DATE_PATTERN = "yyyy-MM-dd";

    private static final String ISO_DATE_SEPARATOR = "-";

    private static final DecimalFormat DECIMAL_FORMAT4 = new DecimalFormat(
            "0000");

    private static final DecimalFormat DECIMAL_FORMAT2 = new DecimalFormat("00");

    /** DateFormat corresponding to ISO pattern */
    private SimpleDateFormat isoDateFormat;

    private SimpleDateFormat localizedDateFormat;

    private String localizedPrompt;

    /** SimpleDateFormat says [a-zA-Z] are reserved. */
    private static final Pattern separatorPattern = Pattern
            .compile("[^a-zA-Z]");

    /** CSS class for popup calendar input field */
    private static final String POP_CAL_INPUT_TEXT_CLASS = "PopCalInput";

    /** Javascript first day of week, Sunday = 0, Monday = 1, ... */
    private int jsFirstDayOfWeek;

    /** Information on date format pattern */
    private PatternInfo patternInfo;

    /** Sub-component that holds string representation of date */
    private HtmlInputText inputText;

    /**
     * Contains info on a date format pattern
     */
    private static class PatternInfo {
        private int yearIndex;

        private int monthIndex;

        private int dayIndex;

        private String separator;

        public PatternInfo(int yearIndex, int monthIndex, int dayIndex,
                String separator) {
            this.yearIndex = yearIndex;
            this.monthIndex = monthIndex;
            this.dayIndex = dayIndex;
            this.separator = separator;
        }

        public int getDayIndex() {
            return dayIndex;
        }

        public int getMonthIndex() {
            return monthIndex;
        }

        public String getSeparator() {
            return separator;
        }

        public int getYearIndex() {
            return yearIndex;
        }
    }

    public PopupCalendarComponent() {
        super();
        setRendererType("PopupCalendar");
    }

    public String getFamily() {
        return "PopupCalendar";
    }

    public HtmlInputText getInputText(FacesContext context) {
        ensureLocalizationInitialized();

        inputText = new HtmlInputText();
        inputText.setId(getInputTextClientId(context));

        // If no selected date, then use the localized prompt pattern
        String selectedDate = getFormattedValue();
        if (selectedDate == null) {
            inputText.setValue(localizedPrompt);
        } else {
            inputText.setValue(selectedDate);
        }

        // Set the tooltip
        inputText.setTitle(localizedPrompt);

        inputText.setStyleClass(POP_CAL_INPUT_TEXT_CLASS);

        return inputText;
    }

    /**
     * @return unique client id for the input text sub component
     */
    public String getInputTextClientId(FacesContext context) {
        return getJavaScriptObjectName(context) + FIELD_SUFFIX;
    }

    private String getFormattedValue() {
        FacesContext context = FacesContext.getCurrentInstance();

        Object value = getValue();
        if (value == null) {
            return null;
        }

        String isoDate = null;

        // Try to convert the model value to an ISO date value
        Converter converter = getConverter();
        if (converter != null) {
            // There is a converter so convert model value to ISO date using
            // converter
            try {
                isoDate = converter.getAsString(context, this, value);
            } catch (ConverterException e) {
                return null;
            }
        } else {
            // No converter
            if (value instanceof String) {
                // Assume that value is already in ISO date format
                isoDate = (String) value;
            } else {
                return null;
            }
        }

        // Convert the ISO date into a localized format
        Date date;
        try {
            date = isoDateFormat.parse(isoDate);
        } catch (ParseException e) {
            // Unable to parse value so act like no date has been selected
            return null;
        }

        // Convert to a localized pattern. This is the normal return path.
        return localizedDateFormat.format(date);
    }

    private void initLocaleDependentFields(Locale locale) {
        // Init a localized ISO date format (just to be safe)
        isoDateFormat = new SimpleDateFormat(ISO_DATE_PATTERN, locale);

        SimpleDateFormat simpleDateFormat;
        String pattern = getDateFormatPattern();
        if (pattern != null) {
            simpleDateFormat = new SimpleDateFormat(pattern, locale);
        } else {
            // Short date format should be all numeric
            DateFormat dateFormat = DateFormat.getDateInstance(
                    DateFormat.SHORT, locale);
            if (dateFormat instanceof SimpleDateFormat) {
                simpleDateFormat = (SimpleDateFormat) dateFormat;
            } else {
                // Javadoc claims this code path is possible (but unlikely) so
                // we initialize a localized ISO date format above to be safe

                // Default to ISO format
                simpleDateFormat = isoDateFormat;
            }
            pattern = simpleDateFormat.toPattern();
        }

        // Validate the pattern
        int yearIndex = pattern.indexOf('y');
        int monthIndex = pattern.indexOf('M');
        int dayIndex = pattern.indexOf('d');
        if (yearIndex == -1 || monthIndex == -1 || dayIndex == -1) {
            // Pattern does not contain all date parts so default to ISO format
            pattern = ISO_DATE_PATTERN;
            yearIndex = pattern.indexOf('y');
            monthIndex = pattern.indexOf('M');
            dayIndex = pattern.indexOf('d');
        }

        // Find the separator or use a default
        Matcher mat = separatorPattern.matcher(pattern);
        String separator = mat.find() ? mat.group() : ISO_DATE_SEPARATOR;

        // Compute the localized pattern strings
        String localPatternChars = simpleDateFormat.getDateFormatSymbols()
                .getLocalPatternChars();
        char yearChar = localPatternChars.charAt(DateFormat.YEAR_FIELD);
        String year = String.valueOf(new char[] { yearChar, yearChar, yearChar,
                yearChar });
        char monthChar = localPatternChars.charAt(DateFormat.MONTH_FIELD);
        String month = String.valueOf(new char[] { monthChar, monthChar });
        char dayChar = localPatternChars.charAt(DateFormat.DATE_FIELD);
        String day = String.valueOf(new char[] { dayChar, dayChar });

        // Handles most common ordering of fields: year is first or last
        StringBuffer prompt = new StringBuffer();
        StringBuffer newPattern = new StringBuffer();
        if (yearIndex < dayIndex && yearIndex < monthIndex) {
            // Year is first
            prompt.append(year);
            prompt.append(separator);

            newPattern.append("yyyy");
            newPattern.append(separator);
        }
        if (dayIndex < monthIndex) {
            prompt.append(day);
            prompt.append(separator);
            prompt.append(month);

            newPattern.append("dd");
            newPattern.append(separator);
            newPattern.append("MM");
        } else {
            prompt.append(month);
            prompt.append(separator);
            prompt.append(day);

            newPattern.append("MM");
            newPattern.append(separator);
            newPattern.append("dd");
        }
        if (yearIndex > dayIndex && yearIndex > monthIndex) {
            // Year is last
            prompt.append(separator);
            prompt.append(year);

            newPattern.append(separator);
            newPattern.append("yyyy");
        }

        // Recompute pattern info based on new pattern
        String newPatternStr = newPattern.toString();
        yearIndex = newPatternStr.indexOf('y');
        monthIndex = newPatternStr.indexOf('M');
        dayIndex = newPatternStr.indexOf('d');
        this.patternInfo = new PatternInfo(yearIndex, monthIndex, dayIndex,
                separator);

        this.localizedDateFormat = new SimpleDateFormat(newPatternStr, locale);
        this.localizedPrompt = prompt.toString().toLowerCase(locale);

        Calendar cal = Calendar.getInstance(locale);
        // Javascript uses 0 to mean Sunday
        this.jsFirstDayOfWeek = cal.getFirstDayOfWeek() - Calendar.SUNDAY;
    }

    private String zeroPad(int number, int width) {
        DecimalFormat formatter;
        if (width == 2) {
            formatter = DECIMAL_FORMAT2;
        } else if (width == 4) {
            formatter = DECIMAL_FORMAT4;
        } else {
            throw new IllegalArgumentException("Width must be 2 or 4");
        }
        return formatter.format(number);
    }

    // @Override
    protected Object getConvertedValue(FacesContext context,
            Object submittedValue) throws ConverterException {
        if (!(submittedValue instanceof String)) {
            return submittedValue;
        }

        // If we have a converter, perform a conversion
        Converter converter = getConverter();
        if (converter == null) {
            return submittedValue;
        }
        return converter.getAsObject(context, this, (String) submittedValue);
    }

    /**
     * @return unique name used as a javascript object identifier
     */
    public String getJavaScriptObjectName(FacesContext context) {
        return getClientId(context)
                .replace(NamingContainer.SEPARATOR_CHAR, '_');
    }

    private void ensureLocalizationInitialized() {
        // The following assertion is true if this code is being called during
        // component rendering
        // assert getFacesContext().getViewRoot() != null;

        Locale locale;
        String localeString = getLocaleString();
        if (localeString != null) {
            String[] parts = localeString.split("[-_]", 3);
            switch (parts.length) {
            case 3:
                locale = new Locale(parts[0], parts[1], parts[2]);
                break;
            case 2:
                locale = new Locale(parts[0], parts[1]);
                break;
            case 1:
            default:
                locale = new Locale(parts[0]);
                break;
            }
        } else {
            // Note that UIViewRoot can be null in the component constructor so
            // make sure this method is not called from there
            locale = getFacesContext().getViewRoot().getLocale();
        }
        initLocaleDependentFields(locale);
    }

    public String getJavaScriptForNewInstance(FacesContext context) {
        StringBuffer js = new StringBuffer("var "
                + getJavaScriptObjectName(context));
        js.append(" = dojo.widget.createWidget('PopupCalendar', { baseId: '");
        js.append(getJavaScriptObjectName(context) + "',\n");

        js.append("calendarParams: { yearIndex: " + patternInfo.getYearIndex());
        js.append(", monthIndex: " + patternInfo.getMonthIndex());
        js.append(", dayIndex: " + patternInfo.getDayIndex());
        js.append(", separator: '" + patternInfo.getSeparator() + "',\n");

        js.append("months: ['");
        DateFormatSymbols dfs = localizedDateFormat.getDateFormatSymbols();
        String[] months = dfs.getMonths();
        for (int i = 0; i < 11; i++) {
            js.append(months[i]);
            js.append("', '");
        }
        js.append(months[11]);
        js.append("'],\n");

        // Use Javascript conventions of Sunday = 0
        js.append("weekdays: ['");
        String[] weekdays = dfs.getShortWeekdays();
        for (int i = Calendar.SUNDAY; i < Calendar.SATURDAY; i++) {
            js.append(weekdays[i]);
            js.append("', '");
        }
        js.append(weekdays[Calendar.SATURDAY]);
        js.append("'],\n");

        js.append("jsFirstWeekday: " + jsFirstDayOfWeek + " }});\n");

        return js.toString();
    }

    // @Override
    public void validate(FacesContext context) {
        // This method transforms the "submitted value" which is the request
        // parameter value to a "submitted value" which is in ISO date format.
        // After this method executes, one of the following will be true:
        // 1) error condition with a queued error message and valid=false
        // 2) submitted value = null to mean no date selected
        // 3) submitted value in ISO date format, meaning date was selected

        String submittedValue = (String) getSubmittedValue();
        if (submittedValue == null) {
            // I think this means that client did not submit a value
            return;
        }

        // If text is initial prompt then this is not an error
        if (Pattern.matches("^" + localizedPrompt + "$", submittedValue)) {
            setSubmittedValue(null);
            return;
        }

        // Check for only whitespace chars which is not an error
        Pattern pat = Pattern.compile("\\S");
        Matcher matcher = pat.matcher(submittedValue);
        if (!matcher.find()) {
            setSubmittedValue(null);
            return;
        }

        Pattern pat2 = Pattern.compile("\\d+");
        Matcher matcher2 = pat2.matcher(submittedValue);
        ArrayList numStrings = new ArrayList(3);
        int i = 0;
        while (matcher2.find() && i < 3) {
            numStrings.add(matcher2.group());
            i++;
        }
        // Check that we have 3 separated numbers
        if (i != 3) {
            errorBadFormat(context);
            return;
        }

        String yearString;
        int dayIndex = patternInfo.getDayIndex();
        int monthIndex = patternInfo.getMonthIndex();
        int yearIndex = patternInfo.getYearIndex();
        if (yearIndex < dayIndex && yearIndex < monthIndex) {
            // Year is first
            yearString = (String) numStrings.remove(0);
        } else {
            // Assume year is last
            yearString = (String) numStrings.remove(2);
        }

        StringBuffer isoString = new StringBuffer();
        int year = Integer.parseInt(yearString);
        isoString.append(zeroPad(year, 4));
        isoString.append(ISO_DATE_SEPARATOR);

        String monthString;
        String dayString;
        if (dayIndex < monthIndex) {
            dayString = (String) numStrings.get(0);
            monthString = (String) numStrings.get(1);
        } else {
            monthString = (String) numStrings.get(0);
            dayString = (String) numStrings.get(1);
        }
        int month = Integer.parseInt(monthString);
        int day = Integer.parseInt(dayString);
        isoString.append(zeroPad(month, 2));
        isoString.append(ISO_DATE_SEPARATOR);
        isoString.append(zeroPad(day, 2));
        setSubmittedValue(isoString.toString());

        super.validate(context);
    }

    private void errorBadFormat(FacesContext context) {
        String pattern = Util.getMessage("popupcalendar.badFormat");
        String summary = MessageFormat.format(pattern,
                new Object[] { localizedPrompt });
        FacesMessage message = new FacesMessage(summary);
        message.setSeverity(FacesMessage.SEVERITY_ERROR);
        context.addMessage(getClientId(context), message);
        setValid(false);
        setSubmittedValue(null);
        return;
    }

    /**
     * <p>
     * Render a textual textfield.
     * </p>
     */
    public String getText() {
        // return (String) getValue();
        Object value = getValue();
        if (value == null) {
            return null;
        } else {
            return value.toString();
        }
    }

    /**
     * @see #getText()
     */
    public void setText(String text) {
        setValue((Object) text);
    }

    // localeString
    private String localeString = null;

    /**
     * <p>
     * Underscore or dash separated locale string used to determine calendar
     * format such as year, month, date ordering, month names, and week names.
     * If null, then the default locale from the view root will be used. For
     * example, "de_DE", "fr_CA", "es".
     * </p>
     */
    public String getLocaleString() {
        if (this.localeString != null) {
            return this.localeString;
        }
        ValueBinding _vb = getValueBinding("localeString");
        if (_vb != null) {
            return (String) _vb.getValue(getFacesContext());
        }
        return null;
    }

    /**
     * <p>
     * Underscore or dash separated locale string used to determine calendar
     * format such as year, month, date ordering, month names, and week names.
     * If null, then the default locale from the view root will be used. For
     * example, "de_DE", "fr_CA", "es".
     * </p>
     * 
     * @see #getLocaleString()
     */
    public void setLocaleString(String localeString) {
        this.localeString = localeString;
    }

    // dateFormatPattern
    private String dateFormatPattern = null;

    /**
     * <p>
     * Pattern to use for date format. A combination of the strings "yyyy",
     * "MM", "dd", plus a separator character, with "yyyy" either first or last.
     * If null, then derive a default one from the locale. See "locale" property
     * for details. If pattern is not valid, then ISO 8601 "yyyy-MM-dd" will be
     * used. For example, "yyyy-MM-dd", "dd.MM.yyyy", "MM/dd/yyyy".
     * </p>
     */
    public String getDateFormatPattern() {
        if (this.dateFormatPattern != null) {
            return this.dateFormatPattern;
        }
        ValueBinding _vb = getValueBinding("dateFormatPattern");
        if (_vb != null) {
            return (String) _vb.getValue(getFacesContext());
        }
        return null;
    }

    /**
     * <p>
     * Pattern to use for date format. A combination of the strings "yyyy",
     * "MM", "dd", plus a separator character, with "yyyy" either first or last.
     * If null, then derive a default one from the locale. See "locale" property
     * for details. If pattern is not valid, then ISO 8601 "yyyy-MM-dd" will be
     * used. For example, "yyyy-MM-dd", "dd.MM.yyyy", "MM/dd/yyyy".
     * </p>
     * 
     * @see #getDateFormatPattern()
     */
    public void setDateFormatPattern(String dateFormatPattern) {
        this.dateFormatPattern = dateFormatPattern;
    }

    // stringValue
    /**
     * <p>
     * This is a String-typed alias for the "value" property and is the model
     * value that will be the initially displayed date in the control and will
     * reflect changes made by the webapp user during post-back. Without any
     * converters, this property is a String in ISO 8601 YYYY-MM-DD format. A
     * value of null means no date is selected. Use the "value" property for
     * non-String types.
     * </p>
     */
    public String getStringValue() {
        return (String) getValue();
    }

    /**
     * <p>
     * This is a String-typed alias for the "value" property and is the model
     * value that will be the initially displayed date in the control and will
     * reflect changes made by the webapp user during post-back. Without any
     * converters, this property is a String in ISO 8601 YYYY-MM-DD format. A
     * value of null means no date is selected. Use the "value" property for
     * non-String types.
     * </p>
     * 
     * @see #getStringValue()
     */
    public void setStringValue(String stringValue) {
        setValue((Object) stringValue);
    }

    // style
    private String style = null;

    /**
     * <p>
     * CSS style attribute.
     * </p>
     */
    public String getStyle() {
        if (this.style != null) {
            return this.style;
        }
        ValueBinding _vb = getValueBinding("style");
        if (_vb != null) {
            return (String) _vb.getValue(getFacesContext());
        }
        return null;
    }

    /**
     * <p>
     * CSS style attribute.
     * </p>
     * 
     * @see #getStyle()
     */
    public void setStyle(String style) {
        this.style = style;
    }

    // styleClass
    private String styleClass = null;

    /**
     * <p>
     * CSS "class" attribute.
     * </p>
     */
    public String getStyleClass() {
        if (this.styleClass != null) {
            return this.styleClass;
        }
        ValueBinding _vb = getValueBinding("styleClass");
        if (_vb != null) {
            return (String) _vb.getValue(getFacesContext());
        }
        return null;
    }

    /**
     * <p>
     * CSS "class" attribute.
     * </p>
     * 
     * @see #getStyleClass()
     */
    public void setStyleClass(String styleClass) {
        this.styleClass = styleClass;
    }

    /**
     * <p>
     * Restore the state of this component.
     * </p>
     */
    public void restoreState(FacesContext _context, Object _state) {
        Object _values[] = (Object[]) _state;
        super.restoreState(_context, _values[0]);
        this.dateFormatPattern = (String) _values[1];
        this.localeString = (String) _values[2];
        this.style = (String) _values[3];
        this.styleClass = (String) _values[4];
    }

    /**
     * <p>
     * Save the state of this component.
     * </p>
     */
    public Object saveState(FacesContext _context) {
        Object _values[] = new Object[5];
        _values[0] = super.saveState(_context);
        _values[1] = this.dateFormatPattern;
        _values[2] = this.localeString;
        _values[3] = this.style;
        _values[4] = this.styleClass;
        return _values;
    }
}
